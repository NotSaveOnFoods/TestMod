using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestMod.Projectiles
{

    public class projectile : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Protojectile");
        }

        public override void SetDefaults()
        {
            projectile.width = 25;
            projectile.height = 40;
            projectile.friendly = true;
            projectile.melee = true;
            projectile.tileCollide = false;
            projectile.penetrate = 3;
            projectile.timeLeft = 200;
            projectile.light = 0.75f;
            projectile.extraUpdates = 1;
            projectile.ignoreWater = true;
        }
        public override void AI()
        {
            projectile.rotation = (float)Math.Atan2((double)projectile.velocity.Y, (double)projectile.velocity.X) + 1.57f;
        }
        public override void OnHitNPC(NPC n, int damage, float knockback, bool crit)
        {
            n.AddBuff(BuffID.OnFire, 180);
            n.AddBuff(BuffID.PetTurtle, 180);
            n.AddBuff(BuffID.Electrified, 180);
            n.AddBuff(BuffID.Poisoned, 180);
        }
    }
}