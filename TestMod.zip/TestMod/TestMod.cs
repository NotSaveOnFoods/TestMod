using Terraria.ModLoader;

namespace TestMod
{
	public class TestMod : Mod
	{
		public TestMod()
		{
		}
	}
}