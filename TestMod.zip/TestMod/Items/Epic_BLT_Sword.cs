using Terraria.ID;
using Terraria.ModLoader;

namespace TestMod.Items
{
	public class Epic_BLT_Sword : ModItem
	{
		public override void SetStaticDefaults()
		{
			// DisplayName.SetDefault("Epic BLT Sword"); // By default, capitalization in classnames will add spaces to the display name. You can customize the display name here by uncommenting this line.
			Tooltip.SetDefault("This is a Developer item.");
		}

		public override void SetDefaults()
		{
			item.damage = 200;
			item.melee = true;
			item.width = 93;
			item.height = 93;
			item.useTime = 10;
			item.useAnimation = 5;
			item.useStyle = 1;
			item.knockBack = 9999999;
			item.value = 10000;
			item.rare = -12;
			item.UseSound = SoundID.Item1;
			item.autoReuse = true;
			item.useTurn = true;
			item.shoot = mod.ProjectileType("projectile");
			item.shootSpeed = 8f;
			item.crit = 100;
		}

		public override void AddRecipes() //craft sword
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.Pwnhammer, 1);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
		
	}
}//shoot projectile