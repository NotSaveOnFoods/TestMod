using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace TestMod.Items.uniquenamesarmor
{
	[AutoloadEquip(EquipType.Body)]
	public class Breastplate2 : ModItem
	{
		public override void SetStaticDefaults()
		{
			base.SetStaticDefaults();
			DisplayName.SetDefault("UniqueArmor");
			Tooltip.SetDefault("This is a Developer item."
				+ "\n+2000 max mana and +100 max minions") ;
		}

		public override void SetDefaults()
		{
			item.width = 30;
			item.height = 20;
			item.value = 9999999;
			item.rare = -12;
			item.defense = 200;
		}

		public override void UpdateEquip(Player player)
		{
			player.statManaMax2 += 2000;
			player.maxMinions+= 20;
			player.buffImmune[BuffID.OnFire] = true;
			player.allDamage += 1.2f;
			player.gravControl = true;
			player.noFallDmg = true;
			player.maxRunSpeed = 200;
			player.lifeRegen = 7;
			player.waterWalk = true;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.Pwnhammer, 1);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}